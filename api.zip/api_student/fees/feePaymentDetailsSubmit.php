<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Allow cross-origin requests
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: *");

// Include the database connection class
include '../DbConnect.php';

class FeePaymentUploader
{
    private $conn;

    public function __construct()
    {
        // Use the existing database connection from DbConnect
        $objDb = new DbConnect();
        $this->conn = $objDb->connect();
    }

    public function handleRequest()
    {
        $method = $_SERVER['REQUEST_METHOD'];

        // Assigning the function according to request methods
        if ($method == 'POST') {
            // Assuming you are sending fee_id, transaction_id, and transaction_screenshot in the form data
            $fee_id = isset($_POST['fee_id']) ? $_POST['fee_id'] : '';
            $transaction_id = isset($_POST['transaction_id']) ? $_POST['transaction_id'] : '';
            $username = isset($_POST['username']) ? $_POST['username'] : '';
            $school_id = isset($_POST['school_id']) ? $_POST['school_id'] : '';

            // Call the function to upload fee payment details
            $this->uploadFeePaymentDetails($fee_id, $transaction_id, $school_id, $username);
        } else {
            http_response_code(405); // Method Not Allowed
            echo json_encode(['error' => 'Method not allowed']);
        }
    }

    public function uploadFeePaymentDetails($fee_id, $transaction_id, $school_id, $username)
    {
        // Check if file is uploaded
        if (isset($_FILES['transaction_screenshot'])) {
            $file = $_FILES['transaction_screenshot'];

            // Handle file upload logic
            $target_dir = "Screenshots/";  // Save screenshots inside the 'screenshots' folder
            $imageFileType = strtolower(pathinfo($file["name"], PATHINFO_EXTENSION));

            // Generate a random 9-character alphanumeric string as the new file name
            $newFileName = substr(bin2hex(random_bytes(5)), 0, 9) . '.' . $imageFileType;
            $target_file = $target_dir . $newFileName;


            // Check file size
            if ($file["size"] > 500000) {
                echo json_encode(["status" => "error", "message" => "File is too large."]);
                exit();
            }


            // Check file size
            if ($file["size"] > 5000000) { // Adjust the file size limit as needed
                echo json_encode(["status" => "error", "message" => "File is too large."]);
                exit();
            }

            // Allow only image file formats (you can modify this condition based on your requirements)
            if (!in_array($imageFileType, ['jpg', 'jpeg', 'png', 'gif'])) {
                echo json_encode(["status" => "error", "message" => "Only image files are allowed."]);
                exit();
            }

            // Move the uploaded file to the target directory
            if (!move_uploaded_file($file["tmp_name"], $target_file)) {
                echo json_encode(["status" => "error", "message" => "Error uploading file."]);
                exit();
            }

            // Insert information into the database
            $paymentQuery = "INSERT INTO FeePaymentVerification (fee_id, transaction_id, transaction_screenshot, username, school_id, verification_status, request_date) 
                 VALUES (:fee_id, :transaction_id, :screenshot_path, :username, :school_id, 'pending', NOW())";

            $paymentStmt = $this->conn->prepare($paymentQuery);
            $paymentStmt->bindParam(':fee_id', $fee_id, PDO::PARAM_STR);
            $paymentStmt->bindParam(':transaction_id', $transaction_id, PDO::PARAM_STR);
            $paymentStmt->bindParam(':username', $username, PDO::PARAM_STR);
            $paymentStmt->bindParam(':school_id', $school_id, PDO::PARAM_STR);
            $paymentStmt->bindParam(':screenshot_path', $target_file, PDO::PARAM_STR);

            if ($paymentStmt->execute()) {
                echo json_encode(["status" => "success", "message" => "Fee payment details uploaded successfully."]);
            } else {
                echo json_encode(["status" => "error", "message" => "Error adding fee payment details to the database."]);
            }
        } else {
            echo json_encode(["status" => "error", "message" => "No file uploaded."]);
        }
    }
}

// Usage
$feeController = new FeePaymentUploader();
$feeController->handleRequest();
?>