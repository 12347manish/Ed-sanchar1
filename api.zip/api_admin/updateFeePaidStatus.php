<?php
ini_set('display_errors', 1);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: *");

include 'DbConnect.php';

class FeeController
{
    
    private $conn;
    public function __construct()
    {
        $db = new DbConnect();
        $this->conn = $db->connect();
    }

    public function handleRequest()
    {
            $method = $_SERVER['REQUEST_METHOD'];

            if ($method === 'POST') {
                $this->updateFee();
            } else {
                // http_response_code(405); // Method Not Allowed
                echo json_encode(['status' => 405, 'message' => 'Method Not Allowed']);
            }
    }

   public function updateFee()
{

    $idsJson = $_POST['fee_ids'] ?? null;
    $transaction_id = $_POST['transaction_id'] ?? null;
    $receipt_no = $_POST['receipt_no'] ?? 0;
    $paid_status = 1;
    
    echo $idsJson;
    echo $transaction_id;
    echo $receipt_no;
    echo $paid_status;
    
    $ids = json_decode($idsJson, true);
    
    if (empty($ids) || !is_array($ids)) {
                throw new Exception('Invalid usernames format');
            }

            foreach ($ids as $id) {

    try {
        $sql = "UPDATE fees SET paid_status = :paid_status, receipt_no = :receipt_no, transaction_id = :transaction_id WHERE id = :id ";
        $stmt = $this->conn->prepare($sql);
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':receipt_no', $receipt_no);
        $stmt->bindParam(':transaction_id', $transaction_id);
        $stmt->bindParam(':paid_status', $paid_status);



        if ($stmt->execute()) {
            $response = ['status' => 1, 'message' => 'Fee information updated successfully.'];
        } else {
            $response = ['status' => 0, 'message' => 'Failed to update fee information.'];
        }
    } catch (PDOException $e) {
        // Log the error for debugging
        error_log("PDOException in updateFee: " . $e->getMessage(), 0);
        $response = ['status' => 0, 'message' => 'Database error.'];
    }
                
            }

    echo json_encode($response);
}


}

$controller = new FeeController();
$controller->handleRequest();
?>
